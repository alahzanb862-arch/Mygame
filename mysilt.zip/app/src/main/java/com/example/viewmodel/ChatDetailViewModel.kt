package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.GeminiAssistantRepository
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.MessageType
import com.example.data.model.PrivateUser
import com.example.data.model.PublicProfile
import com.example.data.model.UiState
import com.example.data.repository.MessagingRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private const val TAG = "ChatDetailVM"

sealed interface AiUiState {
    data object Idle : AiUiState
    data object Loading : AiUiState
    data class Streaming(val text: String) : AiUiState
    data class Success(val text: String) : AiUiState
    data class Error(val message: String) : AiUiState
}

class ChatDetailViewModel(
    private val messagingRepo: MessagingRepository,
    private val aiRepo: GeminiAssistantRepository,
    private val conversationId: String,
    private val currentUserId: String,
) : ViewModel() {

    val messagesState: StateFlow<UiState<List<ChatMessage>>> =
        messagingRepo.observeMessages(currentUserId, conversationId)
            .map<List<ChatMessage>, UiState<List<ChatMessage>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val root = firestoreError ?: error
                Log.w(TAG, "Messages stream error", root)
                emit(UiState.Error(root.message ?: "تعذر تحميل الرسائل"))
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    private val _aiState = MutableStateFlow<AiUiState>(AiUiState.Idle)
    val aiState: StateFlow<AiUiState> = _aiState.asStateFlow()

    private val _lastPrompt = MutableStateFlow("")
    val lastPrompt: StateFlow<String> = _lastPrompt.asStateFlow()

    private val _smartReplies = MutableStateFlow<List<String>>(emptyList())
    val smartReplies: StateFlow<List<String>> = _smartReplies.asStateFlow()

    private val _isLoadingReplies = MutableStateFlow(false)
    val isLoadingReplies: StateFlow<Boolean> = _isLoadingReplies.asStateFlow()

    private val _members = MutableStateFlow<List<PublicProfile>>(emptyList())
    val members: StateFlow<List<PublicProfile>> = _members.asStateFlow()

    private val _actionError = MutableStateFlow<String?>(null)
    val actionError: StateFlow<String?> = _actionError.asStateFlow()

    fun clearError() {
        _actionError.value = null
    }

    fun loadGroupMembers(memberUids: List<String>) {
        viewModelScope.launch {
            _members.value = messagingRepo.resolvePeerProfiles(memberUids, "")
        }
    }

    fun sendMessage(
        conversation: Conversation,
        sender: PrivateUser,
        text: String,
        type: MessageType = MessageType.TEXT,
    ) {
        viewModelScope.launch {
            val res = messagingRepo.sendMessage(conversation, sender, text, type)
            res.onFailure { _actionError.value = it.localizedMessage ?: "تعذر إرسال الرسالة" }
        }
    }

    fun askAi(prompt: String, chatTitle: String) {
        val clean = prompt.trim()
        if (clean.isEmpty()) return
        val recent = (messagesState.value as? UiState.Success)?.data ?: emptyList()
        _lastPrompt.value = clean
        viewModelScope.launch {
            _aiState.value = AiUiState.Loading
            var latest = ""
            try {
                aiRepo.askInChatStream(clean, recent, chatTitle).collect { chunk ->
                    latest = chunk
                    _aiState.value = AiUiState.Streaming(chunk)
                }
                _aiState.value = if (latest.isNotBlank()) AiUiState.Success(latest)
                else AiUiState.Error("لم يتم استلام رد من AI")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _aiState.value = AiUiState.Error(e.localizedMessage ?: "تعذر الاتصال بمساعد AI")
            }
        }
    }

    fun summarizeChat(chatTitle: String) {
        val recent = (messagesState.value as? UiState.Success)?.data ?: emptyList()
        _lastPrompt.value = "تلخيص المحادثة"
        viewModelScope.launch {
            _aiState.value = AiUiState.Loading
            var latest = ""
            try {
                aiRepo.summarizeChatStream(recent, chatTitle).collect { chunk ->
                    latest = chunk
                    _aiState.value = AiUiState.Streaming(chunk)
                }
                _aiState.value = if (latest.isNotBlank()) AiUiState.Success(latest)
                else AiUiState.Error("لم يتم استلام ملخص")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _aiState.value = AiUiState.Error(e.localizedMessage ?: "تعذر تلخيص المحادثة")
            }
        }
    }

    fun askAiWithVoice(wavBytes: ByteArray, chatTitle: String) {
        val recent = (messagesState.value as? UiState.Success)?.data ?: emptyList()
        val recentBlock = recent.takeLast(10).joinToString("\n") { "[${it.senderName}]: ${it.text}" }
        _lastPrompt.value = "أمر صوتي 🎙️"
        viewModelScope.launch {
            _aiState.value = AiUiState.Loading
            var latest = ""
            try {
                aiRepo.askWithAudioStream(
                    wavBytes = wavBytes,
                    contextHeader = "أنت مساعد ذكاء اصطناعي داخل محادثة '$chatTitle'. أحدث الرسائل:\n$recentBlock",
                ).collect { chunk ->
                    latest = chunk
                    _aiState.value = AiUiState.Streaming(chunk)
                }
                _aiState.value = if (latest.isNotBlank()) AiUiState.Success(latest)
                else AiUiState.Error("تعذر تحليل الصوت")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _aiState.value = AiUiState.Error(e.localizedMessage ?: "تعذر معالجة الأمر الصوتي")
            }
        }
    }

    fun fetchSmartReplies() {
        val recent = (messagesState.value as? UiState.Success)?.data ?: emptyList()
        viewModelScope.launch {
            _isLoadingReplies.value = true
            val res = aiRepo.suggestReplies(recent)
            _isLoadingReplies.value = false
            res.onSuccess { _smartReplies.value = it }
            res.onFailure { _actionError.value = it.localizedMessage ?: "تعذر اقتراح الردود" }
        }
    }

    fun shareAiAnswerToChat(conversation: Conversation, sender: PrivateUser) {
        val answer = (_aiState.value as? AiUiState.Success)?.text ?: return
        val prompt = _lastPrompt.value
        val formatted = if (prompt.isNotBlank()) "🤖 $prompt\n\n$answer" else "🤖 $answer"
        sendMessage(conversation, sender, formatted, MessageType.AI_ANSWER)
    }

    fun updateGroupInfo(title: String, description: String?) {
        viewModelScope.launch {
            val res = messagingRepo.updateGroupInfo(conversationId, title, description)
            res.onFailure { _actionError.value = it.localizedMessage ?: "تعذر تحديث المجموعة" }
        }
    }

    fun addMember(currentMembers: List<String>, targetUid: String) {
        viewModelScope.launch {
            val res = messagingRepo.addMemberToGroup(conversationId, currentMembers, targetUid)
            res.onSuccess { loadGroupMembers((currentMembers + targetUid).distinct()) }
            res.onFailure { _actionError.value = it.localizedMessage ?: "تعذر إضافة العضو" }
        }
    }

    fun removeMember(currentMembers: List<String>, currentAdmins: List<String>, targetUid: String) {
        viewModelScope.launch {
            val res = messagingRepo.removeMemberFromGroup(conversationId, currentMembers, currentAdmins, targetUid)
            res.onSuccess { loadGroupMembers(currentMembers.filterNot { it == targetUid }) }
            res.onFailure { _actionError.value = it.localizedMessage ?: "تعذر إزالة العضو" }
        }
    }
}
