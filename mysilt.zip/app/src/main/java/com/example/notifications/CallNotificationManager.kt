package com.example.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.CallMode
import com.example.data.model.CallSession

object CallNotificationManager {

    const val CHANNEL_CALLS = "callai_incoming_calls"
    const val CHANNEL_MESSAGES = "callai_new_messages"

    const val EXTRA_CALL_ID = "extra_call_id"
    const val EXTRA_CONVERSATION_ID = "extra_conversation_id"

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        val callAudioAttr = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val callChannel = NotificationChannel(
            CHANNEL_CALLS,
            "المكالمات الواردة",
            NotificationManager.IMPORTANCE_HIGH,
        ).apply {
            description = "تنبيهات المكالمات الصوتية والمرئية الواردة"
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 500, 300, 500)
            setSound(ringtoneUri, callAudioAttr)
            lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
        }

        val messageChannel = NotificationChannel(
            CHANNEL_MESSAGES,
            "الرسائل الجديدة",
            NotificationManager.IMPORTANCE_HIGH,
        ).apply {
            description = "إشعارات الرسائل والدردشات والمجموعات"
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 200, 100, 200)
            lockscreenVisibility = NotificationCompat.VISIBILITY_PRIVATE
        }

        manager.createNotificationChannel(callChannel)
        manager.createNotificationChannel(messageChannel)
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS,
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun showIncomingCallNotification(context: Context, call: CallSession) {
        if (!hasNotificationPermission(context)) return
        ensureChannels(context)

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_CALL_ID, call.id)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            call.id.hashCode(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val modeLabel = if (call.parsedMode == CallMode.VIDEO) "مكالمة فيديو واردة" else "مكالمة صوتية واردة"
        val notification = NotificationCompat.Builder(context, CHANNEL_CALLS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(call.callerName)
            .setContentText("$modeLabel • @${call.callerUsername}")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        NotificationManagerCompat.from(context).notify(callNotificationId(call.id), notification)
    }

    fun cancelIncomingCallNotification(context: Context, callId: String) {
        NotificationManagerCompat.from(context).cancel(callNotificationId(callId))
    }

    fun showNewMessageNotification(
        context: Context,
        conversationId: String,
        chatTitle: String,
        senderName: String,
        messageText: String,
    ) {
        if (!hasNotificationPermission(context)) return
        ensureChannels(context)

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_CONVERSATION_ID, conversationId)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            conversationId.hashCode(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val body = if (chatTitle == senderName) messageText else "$senderName: $messageText"
        val notification = NotificationCompat.Builder(context, CHANNEL_MESSAGES)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(chatTitle)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        NotificationManagerCompat.from(context).notify(messageNotificationId(conversationId), notification)
    }

    private fun callNotificationId(callId: String): Int = 10_000 + (callId.hashCode() and 0xFFFF)
    private fun messageNotificationId(convId: String): Int = 30_000 + (convId.hashCode() and 0xFFFF)
}
