package com.example.data.repository

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.util.Log
import android.util.Patterns
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.example.R
import com.example.data.firestore.OperationType
import com.example.data.firestore.handleFirestoreError
import com.example.data.model.PrivateUser
import com.example.data.model.PublicProfile
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.auth.userProfileChangeRequest
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

private const val AUTH_TAG = "Auth"

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

internal fun FirebaseAuth.authStateFlow() = callbackFlow {
    trySend(currentUser)
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

private fun mapFirebaseAuthError(error: Throwable, fallback: String): String = when (error) {
    is FirebaseAuthWeakPasswordException ->
        "كلمة المرور ضعيفة، يجب أن تكون 6 أحرف على الأقل"
    is FirebaseAuthInvalidCredentialsException ->
        "البريد الإلكتروني غير صالح أو كلمة المرور غير صحيحة"
    is FirebaseAuthInvalidUserException ->
        "لا يوجد حساب مسجّل بهذا البريد الإلكتروني"
    is FirebaseAuthUserCollisionException ->
        "هذا البريد الإلكتروني مستخدم بالفعل، يمكنك تسجيل الدخول مباشرة"
    is FirebaseNetworkException ->
        "تعذر الاتصال بالشبكة، تحقق من الإنترنت وحاول مجدداً"
    is FirebaseAuthException -> when (error.errorCode) {
        "ERROR_OPERATION_NOT_ALLOWED" ->
            "تسجيل الدخول بالبريد غير مفعّل في Firebase Console (Authentication -> Sign-in method)"
        "ERROR_TOO_MANY_REQUESTS" ->
            "تم إرسال طلبات كثيرة، انتظر قليلاً ثم حاول مجدداً"
        else -> error.localizedMessage ?: fallback
    }
    else -> error.localizedMessage ?: fallback
}

suspend fun signInWithEmailAndPassword(
    email: String,
    password: String,
    auth: FirebaseAuth = Firebase.auth,
): Result<Unit> {
    val cleanEmail = email.trim()
    if (!Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
        return Result.failure(IllegalArgumentException("يرجى إدخال بريد إلكتروني صحيح"))
    }
    if (password.length < 6) {
        return Result.failure(IllegalArgumentException("كلمة المرور يجب أن تكون 6 أحرف على الأقل"))
    }
    return try {
        auth.signInWithEmailAndPassword(cleanEmail, password).await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Log.e(AUTH_TAG, "Email sign-in failed", e)
        Result.failure(IllegalStateException(mapFirebaseAuthError(e, "فشل تسجيل الدخول بالبريد الإلكتروني"), e))
    }
}

suspend fun createUserWithEmailAndPassword(
    email: String,
    password: String,
    displayName: String? = null,
    auth: FirebaseAuth = Firebase.auth,
): Result<Unit> {
    val cleanEmail = email.trim()
    if (!Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
        return Result.failure(IllegalArgumentException("يرجى إدخال بريد إلكتروني صحيح"))
    }
    if (password.length < 6) {
        return Result.failure(IllegalArgumentException("كلمة المرور يجب أن تكون 6 أحرف على الأقل"))
    }
    return try {
        val result = auth.createUserWithEmailAndPassword(cleanEmail, password).await()
        val cleanName = displayName?.trim()?.take(80).orEmpty()
        if (cleanName.isNotEmpty()) {
            try {
                result.user?.updateProfile(
                    userProfileChangeRequest { this.displayName = cleanName },
                )?.await()
            } catch (profileErr: Exception) {
                Log.w(AUTH_TAG, "Non-fatal displayName update error after signup", profileErr)
            }
        }
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Log.e(AUTH_TAG, "Email sign-up failed", e)
        Result.failure(IllegalStateException(mapFirebaseAuthError(e, "تعذر إنشاء الحساب"), e))
    }
}

suspend fun sendPasswordResetEmail(
    email: String,
    auth: FirebaseAuth = Firebase.auth,
): Result<Unit> {
    val cleanEmail = email.trim()
    if (!Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
        return Result.failure(IllegalArgumentException("أدخل بريدك الإلكتروني أولاً لإرسال رابط الاستعادة"))
    }
    return try {
        auth.sendPasswordResetEmail(cleanEmail).await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Log.e(AUTH_TAG, "Password reset failed", e)
        Result.failure(IllegalStateException(mapFirebaseAuthError(e, "تعذر إرسال رابط استعادة كلمة المرور"), e))
    }
}

fun attemptAutoSignIn(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onUnauthenticated: () -> Unit,
    scope: CoroutineScope,
) {
    if (Firebase.auth.currentUser != null) {
        onAuthSuccess()
        return
    }
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (_: Exception) {
        onUnauthenticated()
        return
    }
    if (clientId.isBlank()) {
        onUnauthenticated()
        return
    }
    val activityContext = context.findActivity() ?: context
    val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(true)
        .build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()
    scope.launch {
        try {
            val cred = credentialManager.getCredential(activityContext, request).credential
            if (cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                Firebase.auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await()
                onAuthSuccess()
            } else {
                onUnauthenticated()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            onUnauthenticated()
        }
    }
}

fun onGoogleSignInClicked(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope,
    onAuthCancelled: () -> Unit = {},
) {
    if (Firebase.auth.currentUser != null) {
        onAuthSuccess()
        return
    }
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (_: Exception) {
        onAuthError("إعداد Google Sign-In مفقود: default_web_client_id غير موجود")
        return
    }
    if (clientId.isBlank()) {
        onAuthError("معرّف عميل الويب (default_web_client_id) فارغ في google-services.json")
        return
    }

    val activityContext = context.findActivity() ?: context
    val signInWithGoogleRequest = GetCredentialRequest.Builder()
        .addCredentialOption(GetSignInWithGoogleOption.Builder(serverClientId = clientId).build())
        .build()

    scope.launch {
        try {
            val cred = try {
                credentialManager.getCredential(activityContext, signInWithGoogleRequest).credential
            } catch (noCred: NoCredentialException) {
                Log.w(AUTH_TAG, "GetSignInWithGoogleOption returned NoCredentialException; falling back to GetGoogleIdOption", noCred)
                val fallbackOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(clientId)
                    .setAutoSelectEnabled(false)
                    .build()
                val fallbackRequest = GetCredentialRequest.Builder()
                    .addCredentialOption(fallbackOption)
                    .build()
                credentialManager.getCredential(activityContext, fallbackRequest).credential
            }

            if (cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                Firebase.auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await()
                onAuthSuccess()
            } else {
                onAuthError("نوع بيانات الاعتماد غير مدعوم")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: GetCredentialCancellationException) {
            Log.w(AUTH_TAG, "Google Sign-In flow cancelled or dismissed: ${e.message}", e)
            onAuthCancelled()
        } catch (e: NoCredentialException) {
            Log.e(AUTH_TAG, "No Google credentials found on device", e)
            onAuthError("لم يتم العثور على حساب Google جاهز على الجهاز، تأكد من إضافة حساب Google وتطابق بصمة SHA-1 في Firebase Console")
        } catch (e: GetCredentialException) {
            Log.e(AUTH_TAG, "CredentialManager error during Google Sign-In: ${e.type} - ${e.message}", e)
            onAuthError(e.localizedMessage ?: "تعذر تسجيل الدخول عبر Google (${e.type})")
        } catch (e: Exception) {
            Log.e(AUTH_TAG, "Google Sign-In failed", e)
            onAuthError(mapFirebaseAuthError(e, "فشل تسجيل الدخول عبر Google"))
        }
    }
}

fun signOut(
    credentialManager: CredentialManager,
    scope: CoroutineScope,
    onSignOutComplete: () -> Unit = {},
) {
    scope.launch {
        withContext(NonCancellable) {
            try {
                credentialManager.clearCredentialState(ClearCredentialStateRequest())
            } catch (e: Exception) {
                Log.w(AUTH_TAG, "Failed to clear credential state: ${e.message}")
            } finally {
                Firebase.auth.signOut()
                onSignOutComplete()
            }
        }
    }
}

class AuthProfileRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id),
        ),
    )

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in before accessing Firestore.")

    fun observeMyProfile(userId: String): Flow<PrivateUser?> = flow {
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snapshot ->
                    if (!snapshot.exists()) null
                    else snapshot.toObject(
                        PrivateUser::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val toLog = firestoreError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(toLog, OperationType.GET, path)
                    }
                    throw error
                },
        )
    }

    suspend fun isUsernameAvailable(rawUsername: String): Result<Boolean> {
        val normalized = normalizeUsername(rawUsername)
        if (!isValidUsernameFormat(normalized)) {
            return Result.success(false)
        }
        val path = "usernames/$normalized"
        return try {
            requireUserId()
            val snap = db.collection("usernames").document(normalized).get().await()
            Result.success(!snap.exists())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun registerUsernameAndProfile(
        rawUsername: String,
        displayName: String,
        statusText: String?,
    ): Result<Unit> {
        val user = auth.currentUser
            ?: return Result.failure(IllegalStateException("يجب تسجيل الدخول أولاً"))
        val uid = user.uid
        val normalized = normalizeUsername(rawUsername)
        if (!isValidUsernameFormat(normalized)) {
            return Result.failure(IllegalArgumentException("اسم المستخدم يجب أن يكون 3 إلى 24 حرفاً إنجليزياً صغيراً أو أرقاماً أو _"))
        }
        val cleanName = displayName.trim().take(80)
        if (cleanName.isEmpty()) {
            return Result.failure(IllegalArgumentException("الاسم المعروض مطلوب"))
        }
        val cleanStatus = statusText?.trim()?.take(160)?.takeIf { it.isNotEmpty() }
        val photoUrl = user.photoUrl?.toString()?.take(500)?.takeIf { it.isNotBlank() }
        val email = (user.email ?: "").take(254)

        return try {
            val existingClaim = db.collection("usernames").document(normalized).get().await()
            if (existingClaim.exists() && existingClaim.getString("uid") != uid) {
                return Result.failure(IllegalStateException("اسم المستخدم @$normalized محجوز بالفعل"))
            }

            val batch = db.batch()
            val usernameRef = db.collection("usernames").document(normalized)
            if (!existingClaim.exists()) {
                val claimMap = mutableMapOf<String, Any>(
                    "uid" to uid,
                    "displayName" to cleanName,
                    "createdAt" to FieldValue.serverTimestamp(),
                )
                if (photoUrl != null) claimMap["photoUrl"] = photoUrl
                batch.set(usernameRef, claimMap)
            }

            val publicRef = db.collection("publicProfiles").document(uid)
            val publicMap = mutableMapOf<String, Any>(
                "uid" to uid,
                "username" to normalized,
                "displayName" to cleanName,
                "online" to true,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            if (photoUrl != null) publicMap["photoUrl"] = photoUrl
            if (cleanStatus != null) publicMap["statusText"] = cleanStatus
            batch.set(publicRef, publicMap)

            val privateRef = db.collection("users").document(uid)
            val privateMap = mutableMapOf<String, Any>(
                "uid" to uid,
                "email" to email,
                "username" to normalized,
                "displayName" to cleanName,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            if (photoUrl != null) privateMap["photoUrl"] = photoUrl
            if (cleanStatus != null) privateMap["statusText"] = cleanStatus
            batch.set(privateRef, privateMap)

            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "users/$uid")
            Result.failure(e)
        }
    }

    suspend fun lookupUserByUsername(rawUsername: String): Result<PublicProfile?> {
        val normalized = normalizeUsername(rawUsername)
        if (!isValidUsernameFormat(normalized)) {
            return Result.success(null)
        }
        val path = "usernames/$normalized"
        return try {
            requireUserId()
            val claimSnap = db.collection("usernames").document(normalized).get().await()
            if (!claimSnap.exists()) return Result.success(null)
            val targetUid = claimSnap.getString("uid") ?: return Result.success(null)
            getPublicProfile(targetUid)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun getPublicProfile(targetUid: String): Result<PublicProfile?> {
        val path = "publicProfiles/$targetUid"
        return try {
            requireUserId()
            val snap = db.collection("publicProfiles").document(targetUid).get().await()
            val profile = snap.toObject(
                PublicProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
            )
            Result.success(profile)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun updateProfileInfo(displayName: String, statusText: String?, username: String): Result<Unit> {
        val uid = auth.currentUser?.uid
            ?: return Result.failure(IllegalStateException("User not signed in"))
        val cleanName = displayName.trim().take(80)
        if (cleanName.isEmpty()) return Result.failure(IllegalArgumentException("الاسم مطلوب"))
        val cleanStatus = statusText?.trim()?.take(160) ?: ""

        return try {
            val batch = db.batch()
            batch.update(
                db.collection("users").document(uid),
                mapOf(
                    "displayName" to cleanName,
                    "statusText" to cleanStatus,
                    "updatedAt" to FieldValue.serverTimestamp(),
                ),
            )
            batch.update(
                db.collection("publicProfiles").document(uid),
                mapOf(
                    "displayName" to cleanName,
                    "statusText" to cleanStatus,
                    "updatedAt" to FieldValue.serverTimestamp(),
                ),
            )
            if (isValidUsernameFormat(username)) {
                batch.update(
                    db.collection("usernames").document(username),
                    mapOf("displayName" to cleanName),
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$uid")
            Result.failure(e)
        }
    }

    companion object {
        private val USERNAME_REGEX = Regex("^[a-z0-9_]{3,24}$")

        fun normalizeUsername(raw: String): String =
            raw.trim().removePrefix("@").lowercase()

        fun isValidUsernameFormat(username: String): Boolean =
            USERNAME_REGEX.matches(username)
    }
}
