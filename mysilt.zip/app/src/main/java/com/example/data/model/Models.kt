package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class ConversationType(val wireValue: String) {
    DIRECT("direct"),
    GROUP("group");

    companion object {
        fun fromWire(raw: String?): ConversationType =
            entries.firstOrNull { it.wireValue == raw } ?: DIRECT
    }
}

enum class MessageType(val wireValue: String) {
    TEXT("text"),
    AI_ANSWER("ai_answer"),
    CALL_LOG("call_log");

    companion object {
        fun fromWire(raw: String?): MessageType =
            entries.firstOrNull { it.wireValue == raw } ?: TEXT
    }
}

enum class CallMode(val wireValue: String) {
    AUDIO("audio"),
    VIDEO("video");

    companion object {
        fun fromWire(raw: String?): CallMode =
            entries.firstOrNull { it.wireValue == raw } ?: AUDIO
    }
}

enum class CallStatus(val wireValue: String) {
    RINGING("ringing"),
    ACTIVE("active"),
    ENDED("ended"),
    DECLINED("declined");

    companion object {
        fun fromWire(raw: String?): CallStatus =
            entries.firstOrNull { it.wireValue == raw } ?: ENDED
    }
}

enum class CallEventType(val wireValue: String) {
    TRANSCRIPT("transcript"),
    AI_PROMPT("ai_prompt"),
    AI_ANSWER("ai_answer"),
    SYSTEM("system");

    companion object {
        fun fromWire(raw: String?): CallEventType =
            entries.firstOrNull { it.wireValue == raw } ?: SYSTEM
    }
}

@Keep
@IgnoreExtraProperties
data class PrivateUser(
    @DocumentId val id: String = "",
    val uid: String = "",
    val email: String = "",
    val username: String = "",
    val displayName: String = "",
    val photoUrl: String? = null,
    val statusText: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class PublicProfile(
    @DocumentId val id: String = "",
    val uid: String = "",
    val username: String = "",
    val displayName: String = "",
    val photoUrl: String? = null,
    val statusText: String? = null,
    val online: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class UsernameClaim(
    @DocumentId val id: String = "",
    val uid: String = "",
    val displayName: String = "",
    val photoUrl: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class Contact(
    @DocumentId val id: String = "",
    val contactUid: String = "",
    val username: String = "",
    val displayName: String = "",
    val photoUrl: String? = null,
    val nickname: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class Conversation(
    @DocumentId val id: String = "",
    val type: String = ConversationType.DIRECT.wireValue,
    val title: String = "",
    val description: String? = null,
    val createdBy: String = "",
    val memberUids: List<String> = emptyList(),
    val adminUids: List<String> = emptyList(),
    val lastMessageText: String? = null,
    val lastMessageSenderName: String? = null,
    val lastMessageAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    val conversationType: ConversationType
        get() = ConversationType.fromWire(type)
}

@Keep
@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val conversationId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val text: String = "",
    val messageType: String = MessageType.TEXT.wireValue,
    val memberUids: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    val parsedType: MessageType
        get() = MessageType.fromWire(messageType)
}

@Keep
@IgnoreExtraProperties
data class CallSession(
    @DocumentId val id: String = "",
    val conversationId: String? = null,
    val callerId: String = "",
    val callerName: String = "",
    val callerUsername: String = "",
    val calleeName: String = "",
    val participantUids: List<String> = emptyList(),
    val callMode: String = CallMode.AUDIO.wireValue,
    val status: String = CallStatus.RINGING.wireValue,
    val aiActive: Boolean = false,
    val lastAiPrompt: String? = null,
    val lastAiAnswer: String? = null,
    val lastAiByName: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
    val endedAt: Timestamp? = null,
) {
    val parsedMode: CallMode get() = CallMode.fromWire(callMode)
    val parsedStatus: CallStatus get() = CallStatus.fromWire(status)
}

@Keep
@IgnoreExtraProperties
data class CallEvent(
    @DocumentId val id: String = "",
    val callId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val eventType: String = CallEventType.SYSTEM.wireValue,
    val content: String = "",
    val participantUids: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
) {
    val parsedType: CallEventType get() = CallEventType.fromWire(eventType)
}
